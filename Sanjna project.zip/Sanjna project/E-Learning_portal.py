from flask import Flask, request, render_template_string

app = Flask(__name__)

html = """
<!DOCTYPE html>
<html>
<head>
<title>E-Learning Portal</title>

<style>

body{
    font-family: Arial, sans-serif;
    background:#f4f7fc;
    margin:0;
    padding:30px;
}

.container{
    width:85%;
    margin:auto;
    background:white;
    padding:30px;
    border-radius:15px;
    box-shadow:0px 0px 15px rgba(0,0,0,0.2);
}

h1{
    text-align:center;
    color:#2c3e50;
}

input, select{
    width:100%;
    padding:12px;
    margin-top:10px;
    margin-bottom:15px;
    border:1px solid #ccc;
    border-radius:8px;
}

button{
    width:100%;
    padding:12px;
    background:#007bff;
    color:white;
    border:none;
    border-radius:8px;
    cursor:pointer;
    font-size:16px;
}

button:hover{
    background:#0056b3;
}

.result{
    margin-top:30px;
    padding:20px;
    background:#eef4ff;
    border-radius:10px;
}

.result h2{
    color:#007bff;
}

table{
    width:100%;
    border-collapse:collapse;
    margin-top:20px;
}

table, th, td{
    border:1px solid #ccc;
}

th{
    background:#007bff;
    color:white;
    padding:10px;
}

td{
    padding:10px;
}

</style>

</head>
<body>

<div class="container">

<h1>🎓 E-Learning Portal</h1>

<form method="POST">

<label>Student Name</label>
<input type="text" name="name" required>

<label>Select Your Interest</label>

<select name="interest">

<option>AI & ML</option>
<option>Web Development</option>
<option>Data Science</option>
<option>Cyber Security</option>

</select>

<button type="submit">Get Course Recommendation</button>

</form>

{% if result %}

<div class="result">

<h2>{{result.course}}</h2>

<table>

<tr>
<th>Student Name</th>
<td>{{result.name}}</td>
</tr>

<tr>
<th>Description</th>
<td>{{result.description}}</td>
</tr>

<tr>
<th>Duration</th>
<td>{{result.duration}}</td>
</tr>

<tr>
<th>Mode</th>
<td>{{result.mode}}</td>
</tr>

<tr>
<th>Level</th>
<td>{{result.level}}</td>
</tr>

<tr>
<th>Skills</th>
<td>{{result.skills}}</td>
</tr>

<tr>
<th>Modules</th>
<td>{{result.modules}}</td>
</tr>

<tr>
<th>Career Options</th>
<td>{{result.career}}</td>
</tr>

<tr>
<th>Top Companies</th>
<td>{{result.company}}</td>
</tr>

<tr>
<th>Expected Salary</th>
<td>{{result.salary}}</td>
</tr>

<tr>
<th>Learning Roadmap</th>
<td>{{result.roadmap}}</td>
</tr>

<tr>
<th>Projects</th>
<td>{{result.project}}</td>
</tr>

<tr>
<th>Certificate</th>
<td>{{result.certificate}}</td>
</tr>

</table>

</div>

{% endif %}

</div>

</body>
</html>
"""

@app.route("/", methods=["GET", "POST"])
def home():

    result = None

    if request.method == "POST":

        name = request.form["name"]
        interest = request.form["interest"]

        courses = {

        "AI & ML":{
        "course":"Artificial Intelligence & Machine Learning",
        "duration":"6 Months",
        "mode":"Online + Live Classes",
        "level":"Beginner to Advanced",
        "skills":"Python, Machine Learning, Deep Learning, Data Analysis, NLP, Computer Vision",
        "modules":"Introduction to AI, Python Programming, Machine Learning, Deep Learning, Neural Networks, NLP, Computer Vision, Final Project",
        "career":"AI Engineer, ML Engineer, Data Scientist, Research Scientist",
        "company":"Google, Microsoft, Amazon, IBM, Infosys, TCS",
        "salary":"₹6 LPA - ₹25 LPA",
        "roadmap":"Python → Machine Learning → Deep Learning → Projects → Internship → Placement",
        "project":"Face Recognition System, Chatbot, Recommendation System",
        "certificate":"Industry Recognized Certificate",
        "description":"Artificial Intelligence enables machines to think and learn like humans. Students learn modern AI technologies and real-world applications."
        },

        "Web Development":{
        "course":"Full Stack Web Development",
        "duration":"4 Months",
        "mode":"Online + Practical Labs",
        "level":"Beginner",
        "skills":"HTML, CSS, JavaScript, Bootstrap, Flask, Database",
        "modules":"HTML, CSS, JavaScript, Responsive Design, Flask Framework, Database Connectivity",
        "career":"Frontend Developer, Backend Developer, Full Stack Developer",
        "company":"TCS, Infosys, Wipro, Cognizant",
        "salary":"₹4 LPA - ₹15 LPA",
        "roadmap":"HTML → CSS → JavaScript → Flask → Database → Projects",
        "project":"E-Commerce Website, Student Portal, Blog Website",
        "certificate":"Professional Web Development Certificate",
        "description":"Learn to design and develop modern websites and web applications."
        },

        "Data Science":{
        "course":"Data Science",
        "duration":"6 Months",
        "mode":"Online",
        "level":"Intermediate",
        "skills":"Python, Pandas, NumPy, Data Visualization, Statistics",
        "modules":"Python, Data Analysis, Data Visualization, Statistics, Machine Learning",
        "career":"Data Analyst, Data Scientist, Business Analyst",
        "company":"IBM, Accenture, Deloitte",
        "salary":"₹5 LPA - ₹20 LPA",
        "roadmap":"Python → Data Analysis → Visualization → Machine Learning",
        "project":"Sales Analysis Dashboard, Prediction System",
        "certificate":"Data Science Professional Certificate",
        "description":"Learn to analyze data and generate insights for business decisions."
        },

        "Cyber Security":{
        "course":"Cyber Security",
        "duration":"5 Months",
        "mode":"Online + Lab",
        "level":"Beginner to Advanced",
        "skills":"Ethical Hacking, Network Security, Penetration Testing",
        "modules":"Networking, Security Fundamentals, Ethical Hacking, Pen Testing",
        "career":"Security Analyst, Ethical Hacker, Security Engineer",
        "company":"Cisco, IBM, Microsoft",
        "salary":"₹5 LPA - ₹18 LPA",
        "roadmap":"Networking → Security → Ethical Hacking → Certification",
        "project":"Network Scanner, Vulnerability Assessment Tool",
        "certificate":"Cyber Security Certificate",
        "description":"Learn to protect systems and networks from cyber attacks."
        }

        }

        result = courses[interest]
        result["name"] = name

    return render_template_string(html, result=result)

if __name__ == "__main__":
    app.run(debug=True)